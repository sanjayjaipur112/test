WASender Standalone Executable
=============================

This is the standalone version of WASender, which includes all necessary dependencies in a single executable file.

Installation:
1. Extract all files from the ZIP archive to a folder of your choice
2. Run WASender.exe to start the application

Requirements:
- Windows 7 or later
- .NET Framework 4.6.1 or later
- Google Chrome browser installed

Notes:
- The standalone version includes all the same features as the regular version
- Updates may need to be downloaded manually from the official website
- For any issues, please contact support at support@wasender.com

Thank you for using WASender!
